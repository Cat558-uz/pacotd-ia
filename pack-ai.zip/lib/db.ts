import { drizzle } from 'drizzle-orm/node-postgres'
import { pgTable, text, jsonb, timestamp } from 'drizzle-orm/pg-core'
import { Pool } from 'pg'
import { eq } from 'drizzle-orm'

export const forgeWorkspaces = pgTable('forge_workspaces', {
  id: text('id').primaryKey(),
  name: text('name').notNull().default('Novo projeto'),
  tabs: jsonb('tabs').notNull().default([]),
  memories: jsonb('memories').notNull().default([]),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

const pool = new Pool({ connectionString: process.env.DATABASE_URL })
export const db = drizzle(pool)

export type ForgeTab = { id: string; name: string; prompt: string; code: string; messages: { role: 'user' | 'assistant'; content: string }[] }
export type ForgeMemory = { id: string; text: string; createdAt: string }

export async function getWorkspace(id: string) {
  const rows = await db.select().from(forgeWorkspaces).where(eq(forgeWorkspaces.id, id)).limit(1)
  return rows[0]
}

export async function saveWorkspace(id: string, payload: { name?: string; tabs?: ForgeTab[]; memories?: ForgeMemory[] }) {
  const existing = await getWorkspace(id)
  if (existing) {
    await db.update(forgeWorkspaces).set({ ...payload, updatedAt: new Date() }).where(eq(forgeWorkspaces.id, id))
  } else {
    await db.insert(forgeWorkspaces).values({ id, name: payload.name ?? 'Novo projeto', tabs: payload.tabs ?? [], memories: payload.memories ?? [] })
  }
}
וע
