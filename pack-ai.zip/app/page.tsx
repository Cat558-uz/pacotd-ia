'use client'

import { useState } from 'react'
import {
  Bot, Check, ChevronDown, Code2, Copy, Download, FileCode2, FolderOpen,
  GitBranch, History, Lightbulb, Loader2, Menu, MessageSquareText, Play,
  Plus, Search, Settings2, Sparkles, Terminal, WandSparkles, X,
} from 'lucide-react'

const starterCode = `local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local gui = Instance.new("ScreenGui")
gui.Name = "SpeedBoostUI"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local button = Instance.new("TextButton")
button.Size = UDim2.fromOffset(180, 48)
button.Position = UDim2.new(0.5, -90, 0.8, 0)
button.BackgroundColor3 = Color3.fromRGB(49, 120, 246)
button.Text = "ATIVAR BOOST"
button.TextColor3 = Color3.new(1, 1, 1)
button.Font = Enum.Font.GothamBold
button.TextSize = 14
button.Parent = gui

Instance.new("UICorner", button).CornerRadius = UDim.new(0, 10)

button.Activated:Connect(function()
  local character = player.Character
  local humanoid = character and character:FindFirstChildOfClass("Humanoid")
  if not humanoid then return end

  humanoid.WalkSpeed = 32
  button.Text = "BOOST ATIVO"
  TweenService:Create(button, TweenInfo.new(0.2), {
    BackgroundColor3 = Color3.fromRGB(83, 190, 135)
  }):Play()
end)`

const examples = ['Sistema de moedas com salvamento', 'Porta que abre por proximidade', 'Leaderboard global com DataStore']
const history = [
  { title: 'Speed Boost UI', time: 'agora', active: true },
  { title: 'Sistema de moedas', time: 'há 2h' },
  { title: 'Porta com proximidade', time: 'ontem' },
  { title: 'Leaderboard global', time: 'há 3 dias' },
]

export default function Page() {
  const [prompt, setPrompt] = useState('')
  const [code, setCode] = useState(starterCode)
  const [isGenerating, setIsGenerating] = useState(false)
  const [copied, setCopied] = useState(false)
  const [ran, setRan] = useState(false)
  const [mobileMenu, setMobileMenu] = useState(false)

  async function generateCode() {
    const request = prompt.trim()
    if (!request || isGenerating) return
    setIsGenerating(true)
    setRan(false)

    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: request }),
      })
      const data = await response.json()
      if (!response.ok || typeof data.response !== 'string') {
        throw new Error(data.error || 'Não foi possível gerar o código.')
      }
      setCode(data.response)
    } catch (error) {
      setCode(`-- Erro ao gerar o código\n-- ${error instanceof Error ? error.message : 'Tente novamente.'}`)
    } finally {
      setIsGenerating(false)
    }
  }

  function copyCode() {
    navigator.clipboard?.writeText(code)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  function downloadCode() {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'roblox-forge-script.lua'
    link.click()
    URL.revokeObjectURL(url)
  }

  function runPreview() {
    setRan(true)
    window.setTimeout(() => setRan(false), 1800)
  }

  return (
    <main className="forge-shell">
      <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
        <div className="brand-row"><div className="brand-mark"><Code2 size={18} /></div><span>Roblox Forge</span><button className="close-mobile" onClick={() => setMobileMenu(false)} aria-label="Fechar menu"><X size={18} /></button></div>
        <button className="new-project" onClick={() => { setPrompt(''); setCode(starterCode); setMobileMenu(false) }}><Plus size={17} /> Novo projeto</button>
        <nav className="side-nav" aria-label="Navegação principal"><button className="nav-item active"><WandSparkles size={17} /> Gerador <span className="shortcut">⌘ K</span></button><button className="nav-item"><FolderOpen size={17} /> Meus projetos</button><button className="nav-item"><History size={17} /> Histórico</button></nav>
        <div className="side-section-label">PROJETOS RECENTES</div>
        <div className="project-list">{history.map((item) => <button className={`project-item ${item.active ? 'selected' : ''}`} key={item.title} onClick={() => setPrompt(item.title)}><FileCode2 size={15} /><span>{item.title}<small>{item.time}</small></span></button>)}</div>
        <div className="sidebar-bottom"><button className="nav-item"><Settings2 size={17} /> Configurações</button><div className="profile"><div className="avatar">VC</div><div><strong>Victor Costa</strong><small>Plano gratuito</small></div><ChevronDown size={15} /></div></div>
      </aside>
      <section className="workspace">
        <header className="topbar"><button className="mobile-menu" onClick={() => setMobileMenu(true)} aria-label="Abrir menu"><Menu size={19} /></button><div className="breadcrumb"><span>Gerador</span><span>/</span><b>Speed Boost UI</b></div><div className="top-actions"><button className="ghost-btn"><GitBranch size={16} /> GitHub</button><button className="icon-btn" aria-label="Pesquisar"><Search size={17} /></button><div className="status-dot"><span /> Online</div></div></header>
        <div className="content-area">
          <section className="hero-copy"><div className="eyebrow"><Sparkles size={14} /> IA especializada em Roblox</div><h1>Transforme ideias em<br /><em>código que funciona.</em></h1><p>Descreva o que você quer criar. O Forge escreve scripts Luau limpos, seguros e prontos para usar no Roblox Studio.</p></section>
          <section className="prompt-card"><div className="prompt-label"><MessageSquareText size={16} /> O que você quer construir?</div><textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) { event.preventDefault(); generateCode() } }} placeholder="Ex: Crie um sistema de moedas com leaderboard e salvamento..." aria-label="Descreva seu código" /><div className="example-row">{examples.map((example) => <button key={example} onClick={() => setPrompt(example)}>{example}</button>)}</div><div className="prompt-footer"><div className="prompt-hints"><button onClick={() => setPrompt(examples[1])}><Lightbulb size={14} /> Ver exemplo</button><span>Enter para gerar · Shift + Enter para nova linha</span></div><button className="generate-btn" onClick={generateCode}>{isGenerating ? <Loader2 className="spin" size={16} /> : <Sparkles size={16} />} {isGenerating ? 'Criando...' : 'Gerar código'}</button></div></section>
          <div className="section-heading"><div><h2>Seu código</h2><span>Luau · {code.split('\n').length} linhas</span></div><div className="code-actions"><button onClick={copyCode}>{copied ? <Check size={15} /> : <Copy size={15} />} {copied ? 'Copiado' : 'Copiar'}</button><button onClick={downloadCode}><Download size={15} /> Baixar</button></div></div>
          <section className="editor-card"><div className="editor-tabs"><div className="file-tab"><FileCode2 size={15} /> speed-boost-ui.lua <span>×</span></div><div className="editor-tools"><button aria-label="Executar código" onClick={runPreview} className={ran ? 'tool-active' : ''}><Play size={14} /></button><button aria-label="Abrir terminal"><Terminal size={14} /></button></div></div><div className="code-editor"><div className="line-numbers">{code.split('\n').map((_, index) => <span key={index}>{index + 1}</span>)}</div><pre><code>{code}</code></pre></div><div className="editor-footer"><span><span className="green-dot" /> {ran ? 'Prévia iniciada' : 'Código validado'}</span><span>Luau 0.622 · Roblox Studio</span></div></section>
          <footer className="tip"><Bot size={17} /><span><strong>Dica do Forge</strong> — Seja específico sobre onde o script deve rodar (ServerScriptService, StarterPlayer ou LocalScript) para obter melhores resultados.</span></footer>
        </div>
      </section>
    </main>
  )
}
