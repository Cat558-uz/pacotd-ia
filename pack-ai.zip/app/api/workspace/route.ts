import { NextResponse } from 'next/server'
import { getWorkspace, saveWorkspace } from '@/lib/db'

function validId(value: unknown) {
  return typeof value === 'string' && /^[a-zA-Z0-9_-]{8,80}$/.test(value)
}

export async function GET(request: Request) {
  const id = new URL(request.url).searchParams.get('id')
  if (!validId(id)) return NextResponse.json({ error: 'Workspace inválido.' }, { status: 400 })
  try {
    const workspace = await getWorkspace(id)
    return NextResponse.json(workspace ?? { id, name: 'Novo projeto', tabs: [], memories: [] })
  } catch {
    return NextResponse.json({ error: 'Banco indisponível.' }, { status: 503 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    if (!validId(body?.id)) return NextResponse.json({ error: 'Workspace inválido.' }, { status: 400 })
    await saveWorkspace(body.id, { name: body.name, tabs: body.tabs, memories: body.memories })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Não foi possível salvar.' }, { status: 500 })
  }
}
