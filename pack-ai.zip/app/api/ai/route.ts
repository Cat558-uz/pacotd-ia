import { generateText } from 'ai'
import { NextResponse } from 'next/server'

const SYSTEM_PROMPT = `Você é o Roblox Forge AI, especialista em Luau e Roblox Studio.
Gere código completo, funcional e seguro para jogos Roblox.
Responda SOMENTE com o código Luau, sem markdown, sem crases e sem explicações.
Use serviços corretos, validações, nomes claros e comentários curtos quando ajudarem.
Quando o pedido não especificar o local, escolha uma implementação apropriada e indique isso em um comentário.
Nunca gere código para explorar, trapacear, roubar contas, burlar sistemas ou prejudicar outros jogadores.`

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const message = typeof body?.message === 'string' ? body.message.trim() : ''

    if (!message || message.length > 4000) {
      return NextResponse.json({ error: 'Descreva um pedido de até 4.000 caracteres.' }, { status: 400 })
    }

    const { text } = await generateText({
      model: 'openai/gpt-5.4-mini',
      system: SYSTEM_PROMPT,
      prompt: message,
      maxOutputTokens: 6000,
    })

    const response = text.replace(/^```(?:lua|luau)?\s*/i, '').replace(/\s*```$/i, '').trim()
    return NextResponse.json({ response })
  } catch (error) {
    console.error('[v0] Erro ao gerar código:', error)
    return NextResponse.json({ error: 'Não foi possível gerar o código agora.' }, { status: 500 })
  }
}
